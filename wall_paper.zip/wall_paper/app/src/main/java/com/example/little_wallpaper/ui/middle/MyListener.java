package com.example.little_wallpaper.ui.middle;

//   fragment给activity传值
//1.定义接口
public interface MyListener{
    public void middleFragmentMsg(String msg);
}
