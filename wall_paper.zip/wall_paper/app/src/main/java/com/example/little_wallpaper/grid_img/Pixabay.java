package com.example.little_wallpaper.grid_img;

import java.util.List;

/*
 * @author zjy
 * @param null
 * @return
 * @date 16:41 2021-07-04
 * @description 这个是存网络的对象
 */

public class Pixabay {
    List<PhotoItem> hits;
}