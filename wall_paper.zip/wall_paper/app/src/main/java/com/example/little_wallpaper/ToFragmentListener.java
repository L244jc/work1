package com.example.little_wallpaper;

//// fragment和activity通信要用的
//public interface ToFragmentListener {
//    void onTypeClick(String message);
//}
